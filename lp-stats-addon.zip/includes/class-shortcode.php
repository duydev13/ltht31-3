<?php

if (!defined('ABSPATH')) exit;

class LP_Stats_Shortcode {

    public function __construct() {
        add_shortcode('lp_total_stats', [$this, 'render']);
    }

    public function render() {
        $courses = LP_Stats::get_total_courses();
        $students = LP_Stats::get_total_students();
        $completed = LP_Stats::get_completed_courses();

        return "
            <div class='lp-stats-box'>
                <p><strong>Tổng khóa học:</strong> $courses</p>
                <p><strong>Tổng học viên:</strong> $students</p>
                <p><strong>Hoàn thành:</strong> $completed</p>
            </div>
        ";
    }
}