<?php

if (!defined('ABSPATH')) exit;

class LP_Stats {

    // Tổng khóa học
    public static function get_total_courses() {
        return wp_count_posts('lp_course')->publish;
    }

    // Tổng học viên
    public static function get_total_students() {
        $users = count_users();
        return $users['total_users'];
    }

    // Khóa học hoàn thành
    public static function get_completed_courses() {
        global $wpdb;

        return $wpdb->get_var("
            SELECT COUNT(*) 
            FROM {$wpdb->prefix}learnpress_user_items 
            WHERE status = 'completed'
        ");
    }
}