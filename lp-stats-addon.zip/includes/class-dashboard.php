<?php

if (!defined('ABSPATH')) exit;

class LP_Stats_Dashboard {

    public function __construct() {
        add_action('wp_dashboard_setup', [$this, 'add_widget']);
    }

    public function add_widget() {
        wp_add_dashboard_widget(
            'lp_stats_widget',
            'LearnPress Statistics',
            [$this, 'render']
        );
    }

    public function render() {
        $courses = LP_Stats::get_total_courses();
        $students = LP_Stats::get_total_students();
        $completed = LP_Stats::get_completed_courses();

        echo "<div class='lp-stats-box'>";
        echo "<p><strong>Tổng khóa học:</strong> $courses</p>";
        echo "<p><strong>Tổng học viên:</strong> $students</p>";
        echo "<p><strong>Đã hoàn thành:</strong> $completed</p>";
        echo "</div>";
    }
}