<?php
/**
 * Plugin Name: LearnPress Stats Dashboard
 * Description: Thống kê LearnPress
 * Version: 1.0
 * Author: Duy
 */

if (!defined('ABSPATH')) exit;

// Đường dẫn plugin
define('LP_STATS_PATH', plugin_dir_path(__FILE__));
define('LP_STATS_URL', plugin_dir_url(__FILE__));

// Include các file
require_once LP_STATS_PATH . 'includes/class-stats.php';
require_once LP_STATS_PATH . 'includes/class-dashboard.php';
require_once LP_STATS_PATH . 'includes/class-shortcode.php';

// Khởi chạy plugin
function lp_stats_init() {
    new LP_Stats_Dashboard();
    new LP_Stats_Shortcode();
}
add_action('plugins_loaded', 'lp_stats_init');

// Load CSS
function lp_stats_enqueue_style() {
    wp_enqueue_style(
        'lp-stats-style',
        LP_STATS_URL . 'assets/css/style.css',
        [],
        '1.0'
    );
}

// Gọi cả admin + frontend
add_action('admin_enqueue_scripts', 'lp_stats_enqueue_style');
add_action('wp_enqueue_scripts', 'lp_stats_enqueue_style');